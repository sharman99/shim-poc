#!/bin/bash

set -ex

#PATH=$PATH:/home/.simulation/

echo $(whoami)
pwd
ls
#mkdir output
#chmod +x filename.sh
#cat > output/filename.txt
#echo 'This is a test' > data.txt

# hardcode allocation ID for now
allocation_id="706705d4-3731-11ee-be56-0242ac120002"
./curl "google.com" 

echo "test"

url=$(./curl -X GET http://localhost:8086/payload/$allocation_id)
#url='https://storage.googleapis.com/test_bucket_sim_on_multiplay/input_test.txt?Expires=1692372468&GoogleAccessId=sim-on-multiplay-test%40unity-ai-simulation-usp-test.iam.gserviceaccount.com&Signature=Cm3e%2BZSXFo%2Fp40mNEep8mf3zEm9pbmWNwWHGznnC777GaDsXJAzm2R%2FkG5tZQIA9WuEi4v0BdinjaNLQsf3rBJuPZJ79McEjZpuawK9cm7quhCmruW5zrRauC4j99ERSO31X8DDFs%2BcFOtU%2FujttERGz0ltq6fGiHe18VptgPOgLBe49Ow0wYmUdA5NlbP07hk65dOZzwyr0AkZxM%2BgePv4GsXzbG6v86GDMni6fpWLJzFtF7nJPjvF%2F2rGH%2FhO586NUX7sGnbaHCSMs3yn7AS1RACG5DxdmzSH%2BM00QuKu2kGt81X9NECoiOTZ3rumzGH3t5f80DimR4%2BLKM%2BilPQ%3D%3D'
echo $url

line=$(./curl -X GET $url)
echo $line

filename="input_test.txt"
if [[ $line == "test_shim_script" ]]; then
    echo "File contents are correct"
else
    echo "File contents are incorrect"
    exit 1
fi

# if ./curl "$url" >$filename; then
#   echo "$filename exists"
#   line=$(head -n 1 $filename)
#   if [[ $line == "test_shim_script" ]]; then
#     echo "File contents are correct"
#     exit 0
#   else
#     echo "File contents are incorrect"
#     exit 1
#   fi
# else
#   echo "$filename does not exist"
#   exit 1
# fi
